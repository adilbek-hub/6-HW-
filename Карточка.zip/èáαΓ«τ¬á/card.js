alert("Я оцениваю свою работу на 100 баллов")
document.body.style.fontFamily = "Outfit, sans-serif";
document.body.style.fontSize = "20px";
let wrapper = document.createElement("div");
wrapper.id = "wrapper";
wrapper.style.marginLeft = "250px"
wrapper.style.maxWidth = "1300px";
wrapper.style.display = "flex";
wrapper.style.marginTop = "60px";
let card = document.createElement("div");
card.className = "card";
card.style.backgroundColor = "#150D31";
card.style.padding = "40px 20px";
card.style.borderRadius = "10px";
card.style.boxShadow = "3px 14px 28px rgba(0,0,0,0.20), 3px 10px 10px rgba(0,0,0,0.22)";
let imgTop = document.createElement("IMG");
imgTop.className = "img-top";
imgTop.src = "image-equilibrium.jpg";
imgTop.style.maxWidth = "400px";
imgTop.style.borderRadius = "20px";
imgTop.style.marginBottom = "10px";
let title = document.createElement("h4");
title.className = "card-title";
title.innerText = "Equilibrium #3954";
title.style.color = "#ffffff";
title.style.marginBottom = "20px";

let text = document.createElement("p");
text.className = "card-text";
text.innerText = "Our Equilibrium collection promotes balance and calm";
text.style.fontSize = "350";
text.style.marginBottom = "20px";
text.style.color = "hsl(240, 50%, 65%)";
text.style.margin = "0";
text.style.maxWidth = "300px";
text.style.lineHeight = "25px";
text.style.marginBottom = "17px";


let div = document.createElement("div");
div.style.display = "flex";
div.style.justifyContent = "space-between";

let info = document.createElement("div");
info.className = "info";

let icon = document.createElement("img");
icon.className = "icon";
icon.src = "icon-ethereum.svg";
icon.style.marginRight = "10px";

let iconText = document.createElement("p");
iconText.className = "icon-text";
iconText.innerText = "0.041 ETH";
iconText.style.fontWeight = "bold";
iconText.style.marginTop = "20px;";
iconText.style.color = "hsl(0, 0%, 100%)";
iconText.style.display = "inline-block"

let time = document.createElement("div");
time.className = "time";
time.style.display = "flex";
time.style.alignItems = "center";
time.style.marginBottom = "120px";

let imgTime = document.createElement("img");
imgTime.className = "time-img";
imgTime.style.marginRight = "5px";
imgTime.src = "./images/icon-clock.svg";

let timeTxt = document.createElement("p");
timeTxt.className = "time-text";
timeTxt.style.color = "hsl(215, 51%, 70%)";
timeTxt.innerText = "3 days left";
timeTxt.style.marginTop = "19px"

let line = document.createElement("hr");
line.style.borderColor = "hsl(215, 32%, 27%)";
line.style.marginTop = "-8px";


let avatar = document.createElement("div");
avatar.className = "avatar";
avatar.style.alignItems = "center";
avatar.style.marginTop = "22px";
avatar.style.display = "flex";


let avatarImg = document.createElement("img");
avatarImg.className = "avatar-img";
avatarImg.src = "./images/image-avatar.png";
avatarImg.style.maxWidth = "35px";
avatarImg.style.marginRight = "15px";
avatarImg.style.border = "2px solid white";
avatarImg.style.borderRadius = "50%";


let avatarTxt = document.createElement("span");
avatarTxt.className = "avatar-text";
avatarTxt.innerText = "Creation of"
avatarTxt.style.fontSize = "17px"
avatarTxt.style.color = "hsl(215, 51%, 70%)";
avatarTxt.style.textAlign = "center";


let userName = document.createElement("span");
userName.className = "user-name";
userName.style.color = "white";
userName.innerText = " Jules Wyvern";

document.body.appendChild(wrapper);
wrapper.appendChild(card);
card.appendChild(imgTop);
card.appendChild(title);
card.appendChild(text);
card.appendChild(div);
div.appendChild(info);
info.appendChild(icon);
info.appendChild(iconText);
div.appendChild(time);
time.appendChild(imgTime);
time.appendChild(timeTxt);
card.appendChild(line);
card.appendChild(avatar);
avatar.appendChild(avatarImg);
avatar.appendChild(avatarTxt);
avatarTxt.appendChild(userName);
